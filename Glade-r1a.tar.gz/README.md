# Glade App Icon

---

## Important

If your version doesn't work run the script in the resources folder, Glade.app/Contents/Resources/glade_install.sh but make sure your pwd is the Resources folder.. i.e.

```sh
cd /Applications/Glade.app/Contents/Resources/;
./glade_install.sh || exec glade_install.sh || sh ./glade_install;
```

but make sure your not root when you run it (brew will be fussy and tell you it wont run) but it will ask for sudo, if your worried check the code first.

---

## Created by

by:		sam @ ukjp

web:	[ukjp.app](https://ukjp.app)

mail:	[sam.aldis](mailto:sam.aldis@ukjp.app)

